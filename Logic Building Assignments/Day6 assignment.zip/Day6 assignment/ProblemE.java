public class ProblemE{
	public static void main(String arg[]){
		int[] numbers={1,2,3,4,5};

		for(int i=0;i<numbers.length;i++){
			System.out.println("Number : "+numbers[i]);
		}
	}
}

/*
in sop statement index value should be passed i instead of 5.
*/