public class ProblemF{
	public static void main(String arg[]){
		int x=5;
		int y=10;
		//int z= x+y;
		int z= 2*(x+y);
		System.out.println("Sum : "+z);
	}
}

/*
all variable should be declared as int instead of float as float stores fraction or decimal value.
equation or sum should be multipy by 2.
*/