public class ProblemB{
	public static void main(String arg[]){
		for(int i=1;i<=5;i++){
			System.out.println("Number : "+i);
		}
	}
}

/*
in for loop condition should be less than and equal to instead of less than.
*/