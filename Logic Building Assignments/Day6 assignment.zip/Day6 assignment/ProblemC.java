public class ProblemC{
	public static void main(String arg[]){
		int x=10;
		if(x==10){
			System.out.println("X is 10");
		}else{
			System.out.println("X is not 10");
		}
	}
}

/*
We can't compare sop statement with variable in if condtion.
*/