public class ProblemA{
	public static void main(String arg[]){
		int x=5;
		int y=10;
		//int z= x+y;
		int z= 2*(x+y);
		System.out.println("Sum : "+z);
	}
}

/*
y is decleared as double but it should be int, as we can't convert double to int.
for 30 we need to multipy equation or sum by 2.
*/