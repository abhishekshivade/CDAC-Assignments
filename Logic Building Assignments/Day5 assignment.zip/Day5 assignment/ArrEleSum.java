class ArrEleSum{
	public static void main(String Arg[]){
		int a[]={1,2,3,4,5};

		int sum=0;

		for(int i : a){
			sum+=i;
		}

		System.out.println("Sum = "+sum);
	}
}