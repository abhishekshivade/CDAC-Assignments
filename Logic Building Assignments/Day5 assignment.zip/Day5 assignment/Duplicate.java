class Duplicate{
	public static void main(String arg[]){
		int a[]={1,2,2,3,4,4,5};
		int d[]=new int[a.length];
		
		

		for(int i:d)
			System.out.println(i);
	}
}